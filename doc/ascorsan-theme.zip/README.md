Ideia para pagina de posts de notícias  	-> https://bootsnipp.com/snippets/Q0Gpv
Ideia para pagina de galeria fullscreen 	-> https://bootsnipp.com/snippets/D0RR1
Ideia para pagina de posts de galeria  		-> https://bootsnipp.com/snippets/XMDRE
Ideia para pagina de posts de galeria   	-> https://bootsnipp.com/snippets/BE3dv
Ideia para pagina de posts de galeria de fotos 	-> https://bootsnipp.com/snippets/EzB6P