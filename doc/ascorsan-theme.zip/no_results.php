
<div class="container">
    <div class="row mb-5">
        <div class="col text-center">
            <h1>Desculpe, não encontramos o que procurava!</h1>
            <img src="<?php bloginfo('template_url'); ?>/img/zero-results.png" height="290" />
            <p>Parece que voce está procurando por um conteúdo que não existe ou foi removido</p>
        </div>
    </div>
</div>

