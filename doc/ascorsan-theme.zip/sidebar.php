<section id="search">
  <?php 
    dynamic_sidebar('Busca'); 
 ?>
</section>
